package org.example;

public class B {
    public B() {
        System.out.println("In B constructor");
    }

}
