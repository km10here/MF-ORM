# MF-ORM
<h2>Lab Manual - Deepanshu Goel</h2>
<h3>Roll Number - 19CSU077</h3>
