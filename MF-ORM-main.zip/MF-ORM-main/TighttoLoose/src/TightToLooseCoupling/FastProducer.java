package TightToLooseCoupling;

public class FastProducer implements IWorker{
    public void First() {
        System.out.println("This is Fast Producer");
    }
}
