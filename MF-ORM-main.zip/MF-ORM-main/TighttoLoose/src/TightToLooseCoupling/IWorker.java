package TightToLooseCoupling;

public interface IWorker {
    public void First();
}
