public class C {

    public C() {
        System.out.println("Calling C Constructor");
    }


}
