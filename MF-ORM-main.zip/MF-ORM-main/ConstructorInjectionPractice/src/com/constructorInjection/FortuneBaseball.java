package com.constructorInjection;

public class FortuneBaseball implements IFortune{

    @Override
    public String getFortune() {
        return "You have a Good Day Today and will Score Goals";
    }
}
