package com.constructorInjection;

public interface IFortune {
    public String getFortune();
}
