package com.constructorInjection;

public interface ICoach {

public String getFortune();
public String getDailyWorkout();
public  void setName(String name);
public  String getName();
}
