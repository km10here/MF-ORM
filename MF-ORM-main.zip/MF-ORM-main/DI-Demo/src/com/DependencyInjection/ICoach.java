package com.DependencyInjection;

public interface ICoach {
    public String getDailyWorkout();
    public String getFortune();
}
