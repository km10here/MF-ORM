package com.DependencyInjection;

public interface IFortune {
    public String getFortune();
}
