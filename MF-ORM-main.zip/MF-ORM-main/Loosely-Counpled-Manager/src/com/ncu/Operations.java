package com.ncu;

public interface Operations {
    public void create();
    public void delete();
    public void update();
    public void read();
}
