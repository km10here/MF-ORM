package com.lifecycle;

public interface IFortune {
    public String getFortune();
}
