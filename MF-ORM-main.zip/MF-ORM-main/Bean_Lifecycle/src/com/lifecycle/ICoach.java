package com.lifecycle;

public interface ICoach {
    public String getDailyWorkout();
    public String getDailyFortune();
}
