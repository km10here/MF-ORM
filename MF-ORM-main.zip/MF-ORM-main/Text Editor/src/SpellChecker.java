public class SpellChecker {
    public SpellChecker()
    {
        System.out.println("Spell Checker constructor Executing");
    }
    public void display() {
        System.out.println("Spell Check Function");
    }
}
