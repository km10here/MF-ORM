package com.ncu.applications;

public interface IWorker {
    void First();
}
